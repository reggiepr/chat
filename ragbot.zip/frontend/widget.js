// Tiny embeddable widget. Usage:
// <script src="https://YOUR_HOST/widget.js" data-client="CLIENT_ID" data-api-key="KEY"></script>

(function(){
  const host = (new URL(document.currentScript.src)).origin;
  const client = document.currentScript.getAttribute('data-client') || '';
  const apiKey = document.currentScript.getAttribute('data-api-key') || '';
  if(!client || !apiKey){ console.warn('widget: missing data-client or data-api-key'); }

  // Styles
  const style = document.createElement('style');
  style.textContent = `
    .rag-widget-btn{position:fixed;right:20px;bottom:20px;padding:12px 16px;border-radius:999px;background:#111;color:#fff;cursor:pointer;z-index:99999}
    .rag-widget{position:fixed;right:20px;bottom:70px;width:360px;height:520px;border:1px solid #ddd;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.15);background:#fff;display:none;flex-direction:column;z-index:99999}
    .rag-head{padding:10px 12px;border-bottom:1px solid #eee;font-weight:600}
    .rag-body{flex:1;overflow:auto;padding:10px 12px;font-family:system-ui, sans-serif;font-size:14px}
    .rag-input{display:flex;border-top:1px solid #eee}
    .rag-input input{flex:1;padding:10px;border:0}
    .rag-input button{padding:10px 12px;border:0;background:#111;color:#fff;cursor:pointer}
    .rag-msg-user{margin:8px 0;text-align:right}
    .rag-msg-bot{margin:8px 0;text-align:left}
    .rag-src{font-size:12px;color:#666;margin-top:8px}
  `;
  document.head.appendChild(style);

  // UI
  const btn = document.createElement('div'); btn.className='rag-widget-btn'; btn.textContent='Chat';
  const wrap = document.createElement('div'); wrap.className='rag-widget';
  wrap.innerHTML = '<div class="rag-head">Ask us anything</div><div class="rag-body" id="ragBody"></div><div class="rag-input"><input id="ragInput" placeholder="Type your question..."><button id="ragSend">Send</button></div>';
  document.body.appendChild(btn); document.body.appendChild(wrap);
  const body = wrap.querySelector('#ragBody'); const input = wrap.querySelector('#ragInput'); const send = wrap.querySelector('#ragSend');

  btn.onclick = ()=>{ wrap.style.display = (wrap.style.display==='flex'?'none':'flex'); if(wrap.style.display==='flex'){wrap.style.display='flex';} };
  send.onclick = async ()=>{
    const q = input.value.trim(); if(!q) return;
    body.innerHTML += '<div class="rag-msg-user">'+q+'</div>';
    input.value='';
    const res = await fetch(host + '/chat', {method:'POST', headers:{'Content-Type':'application/json','x-api-key': apiKey}, body: JSON.stringify({client_id: client, question: q, top_k: 4, stream: false})});
    if(!res.ok){ body.innerHTML += '<div class="rag-msg-bot">Error: '+res.status+'</div>'; return; }
    const data = await res.json();
    body.innerHTML += '<div class="rag-msg-bot">'+data.answer+'<div class="rag-src">Sources: '+(data.sources||[]).join(', ')+'</div></div>';
    body.scrollTop = body.scrollHeight;
  };
})();